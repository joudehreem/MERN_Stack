import { useState } from 'react'
import './App.css'
import UserForm from './UserForm.jsx'

function App() {

  return (
    <>
    <UserForm/>
    </>
  )
}

export default App
