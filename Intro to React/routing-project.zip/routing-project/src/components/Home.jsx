export default function Home() {
  return (
    <div>
      <h1>Welcome</h1>
    </div>
  )
}