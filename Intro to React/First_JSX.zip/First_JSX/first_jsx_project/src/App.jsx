import Content from "./assets/content"
function App() {

  return (
    <>
    <Content/>
    </>
  )

}

export default App
