import "./App.css";
import UserForm from "./components/UserForm";

function App() {
  return (
    <>
      <UserForm />
    </>
  );
}

export default App;
