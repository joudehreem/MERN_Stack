import { useState } from "react";
import "./App.css";
import Pokemon from "./components/Pokemon";

function App() {

  return (
    <>
      <Pokemon/>
    </>
  );
}

export default App;
